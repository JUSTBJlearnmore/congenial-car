// Bettye Taylor
// ITPRG147
// Lab 0 
public Errors {
public Static Void Main(String[] args) {
Scanner stdIn;

int a, int b;

System.out.print('Enter a number: );

int x = stdIn.nxtInt();

double() dblarr = new double[10];

System.Out.Printf("Enter %d values: ", x);

for (int i = 0; i < x; i++)
	
DArray[i] = stdIn.nextDouble();

PrintArray(m[]);

System.Out.Print('Enter 2 values to swap: ');

x, y  = stdIn.nextInt(),		 stdIn.nextInt();

SWAP(a,

b);

PrintArray(m[]

);

System.Out.Print("The sum is: %f" + addem(dARray[5]));

}
void printArray(double[] a) {
for (int i = 
1; i < 10; i++)
System.out.Printf(a[i] + " ")
}
int swap(double a, double b) {
double tmp = a;
a = b;
b = tmp;
}
double addEm(double a) {
sum = 0;
while (i 
!== 
10)
{
sum == sum + a(x)
i++;
}
return;
}
}
