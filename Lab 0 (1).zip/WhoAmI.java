// RKS Func
// Bettye Taylor 
// ITPRG147
// Lab 0
Find the errors and correct them
What is this supposed to be doing ?
public class Obscuro  {

public static void main(String[] args) {
String x;
{
Scanner a = new 

Scanner(System.	in
);
System.out.print("> );
x 
= a.nextLine();}String a = x;int i = a.charAt(1);int k = x.length();
do {
if (i == x.charAt(1))
i = 0;
else if (i < -500) {
k = i + 70;
}
else if (i < 0) {
else 
k = i - 70; 
}
a = Q(a);
i++;
k = i;
while (k < x.length());
System.out.println(a)
}
static String Q(String x) {char[] k = x.toCharArray();int i, j;i = 0; j = ++i;
char[] y = new char[x.length()];
for (i = 0; i < x.length(); i++) 
if (i == 0 || x.charAt(i-j
) == ' ') {
k[i] = x.toUpperCase().charAt(i);
else; if (j < 0) ;
else if (j = = 0) {
}


else 
y[i] = k[i];}
x = new String(y);return x;}}
